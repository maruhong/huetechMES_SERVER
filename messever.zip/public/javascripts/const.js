module.exports = Object.const({
    MES: '공정관리프로그램',
    MENU: 'Menu',
    SEARCH: '검색',
    INPUT: '입력'
});