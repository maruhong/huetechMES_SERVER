const constants = {
    'menu': '메뉴',
    'test_title': '실습'
}