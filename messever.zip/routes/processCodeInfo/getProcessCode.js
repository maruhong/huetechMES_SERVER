var express = require('express');
var router = express.Router();

var conn = require('../util/dbConn.js');
var conf = require('../util/config');

/*
if (!module.parent) {
  const port = process.env.PORT || 3000;

  app.listen(port, () => {
    console.log("Express server listening on port " + port + ".");
   });
}
*/
router.get('/api/getProcessCodeAll', function(req, res, next) {
  console.log ("getEmpInfo.js /api/PROJECT_Master >>>>>1 ")
  conn.executeQuery("SELECT IO_CODE_SEQ AS ID, IO_CODE_D_NM AS CODENAME FROM C_CODE_D where IO_CODE_M = 'P001' AND USE_YN ='Y'", function(result){
    console.log("In Index : " + JSON.stringify(result));
    res.send(JSON.stringify(result));
  });
});

router.get('/api/getProcessCodeByProject/:projectCode', function(req, res, next) {
  let projectCode = req.param.projectCode
  console.log ("getEmpInfo.js /api/PROCESS_Master >>>>>1 ")
  conn.executeQuery("SELECT IO_CDOE_SEQ AS ID, IO_CDOE_D_NM AS CODENAME FROM C_CDOE_D WHERE IO_CODE_CD IN (SELECT PROCESS_CD FROM PROCESS_MASTER where PROJECT_CD = ?)", [projectCode], function(result){
    console.log("In Index : " + JSON.stringify(result));
    res.send(JSON.stringify(result));
  });
});

module.exports = router;
